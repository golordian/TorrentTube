const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const fs = require('fs');

let commentOrPostOutput = '';

app.use(bodyParser.json());

// Serve static files (CSS, JavaScript, images)
app.use(express.static('public'));

const PORT = 3001;
const POSTS_FILE = 'posts.json';

// Function to retrieve all posts from the file system
const getAllPosts = () => {
  try {
    const data = fs.readFileSync(POSTS_FILE);
    return JSON.parse(data);
  } catch (err) {
    console.error(err);
    return [];
  }
};

// Function to save all posts to the file system
const saveAllPosts = (posts) => {
  fs.writeFileSync(POSTS_FILE, JSON.stringify(posts));
};

// Route to handle adding a new post
app.post('/posts', (req, res) => {
  const newPost = {
    id: Date.now(),
    author: req.connection.remoteAddress,
    content: req.body.content
  };

  const posts = getAllPosts();
  posts.push(newPost);
  saveAllPosts(posts);

  res.send({ message: 'Post added successfully!' });
});

// Route to handle retrieving all posts
app.get('/posts', (req, res) => {
  res.send(getAllPosts());
});

// Route to display the main page
app.get('/', (req, res) => {
  const posts = getAllPosts();
  const html = `
    <html>
      <head>
    <meta charset="UTF-8">
    <title>WebTorrent video player</title>
    <style>
      #output video {
        width: 100%;
      }
      #progressBar {
          height: 5px;
          width: 0%;
          background-color: #35b44f;
          transition: width .4s ease-in-out;
      }
      body.is-seed .show-seed {
          display: inline;
      }
      body.is-seed .show-leech {
          display: none;
      }
      .show-seed {
          display: none;
      }
      #status code {
          font-size: 90%;
          font-weight: 700;
          margin-left: 3px;
          margin-right: 3px;
          border-bottom: 1px dashed rgba(255,255,255,0.3);
      }

      .is-seed #hero {
          background-color: #154820;
          transition: .5s .5s background-color ease-in-out;
      }
      #hero {
          background-color: #2a3749;
      }
      #status {
          color: #fff;
          font-size: 17px;
          padding: 5px;
      }
      a:link, a:visited {
          color: #30a247;
          text-decoration: none;
      }
    </style>

        <link rel="stylesheet" href="myapp/style.css">
        <title>My First Webpage</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: lightblue;
      text-align: center;
    }
    header {
      background-color: navy;
      padding: 20px;
      color: white;
      font-size: 24px;
      text-shadow: 2px 2px gray;
    }
    nav ul {
      display: inline-block;
      list-style-type: none;
      margin: 0;
      padding: 0;
    }
    nav li {
      display: inline-block;
      margin-right: 20px;
    }
    nav a {
      color: white;
      text-decoration: none;
      font-size: 20px;
    }
    main {
      max-width: 800px;
      margin: 0 auto;
      background-color: white;
      padding: 20px;
      text-align: left;
      border: 5px solid navy;
    }
    h1, h2 {
      color: navy;
    }
    img.portrait {
      border: 5px solid navy;
      float: right;
      margin-left: 20px;
      width: 150px;
      height: 150px;
    }
    p {
      font-size: 18px;
      line-height: 1.5;
    }
  </style>
      </head>
      <body>
        <header>
    <nav>
      <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#contact">Contact</a></li>
      </ul>
    </nav>
  </header>
     <main>
       <img src="https://via.placeholder.com/150x150" alt="Portrait" class="portrait">
       <h1 id="home">Welcome to My First Webpage</h1>
       <p>This is a sample webpage with headings, links in the menu, and sample content in the body.</p>
       <h2 id="about">About Us</h2>
       <p>We are a team of developers and designers dedicated to creating high-quality websites and applications. Our goal is to help businesses succeed in the digital world by providing them with cutting-edge technology and innovative solutions. We have a passion for the work we do, and we are committed to delivering outstanding results for our clients. </p>
  
      <h1>Forum</h1>
        <form action="/posts" method="post">
        <textarea name="content"></textarea>
        <button type="submit">Post</button>
      </form>
        <ul>
          ${posts.map(post => `
            <li>
              <strong>${post.author}</strong>
              <p>${post.content}</p>
             ${commentOrPostOutput && `<p>${commentOrPostOutput}</p>`}
            </li>
         `).join('')}
        </ul>
        <div id="hero">
      <div id="output">
        <div id="progressBar"></div>
        <!-- The video player will be added here -->
      </div>
      <!-- Statistics -->
      <div id="status">
        <div>
          <span class="show-leech">Downloading </span>
          <span class="show-seed">Seeding </span>
          <code>
            <!-- Informative link to the torrent file -->
            <a id="torrentLink" href="https://webtorrent.io/torrents/sintel.torrent">sintel.torrent</a>
          </code>
          <span class="show-leech"> from </span>
          <span class="show-seed"> to </span>
          <code id="numPeers">0 peers</code>.
        </div>
        <div>
          <code id="downloaded"></code>
          of <code id="total"></code>
          — <span id="remaining"></span><br/>
          &#x2198;<code id="downloadSpeed">0 b/s</code>
          / &#x2197;<code id="uploadSpeed">0 b/s</code>
        </div>
      </div>
    </div>
    <!-- Include the latest version of WebTorrent -->
    <script src="https://cdn.jsdelivr.net/npm/webtorrent@latest/webtorrent.min.js"></script>

    <!-- Moment is used to show a human-readable remaining time -->
    <script src="http://momentjs.com/downloads/moment.min.js"></script>

    <script>
      const torrentId = 'https://webtorrent.io/torrents/sintel.torrent'

      const client = new WebTorrent()

      // HTML elements
      const $body = document.body
      const $progressBar = document.querySelector('#progressBar')
      const $numPeers = document.querySelector('#numPeers')
      const $downloaded = document.querySelector('#downloaded')
      const $total = document.querySelector('#total')
      const $remaining = document.querySelector('#remaining')
      const $uploadSpeed = document.querySelector('#uploadSpeed')
      const $downloadSpeed = document.querySelector('#downloadSpeed')

      // Download the torrent
      client.add(torrentId, function (torrent) {

        // Torrents can contain many files. Let's use the .mp4 file
        const file = torrent.files.find(function (file) {
          return file.name.endsWith('.mp4')
        })

        // Stream the file in the browser
        file.appendTo('#output')

        // Trigger statistics refresh
        torrent.on('done', onDone)
        setInterval(onProgress, 500)
        onProgress()

        // Statistics
        function onProgress () {
          // Peers
          $numPeers.innerHTML = torrent.numPeers + (torrent.numPeers === 1 ? ' peer' : ' peers')

          // Progress
          const percent = Math.round(torrent.progress * 100 * 100) / 100
          $progressBar.style.width = percent + '%'
          $downloaded.innerHTML = prettyBytes(torrent.downloaded)
          $total.innerHTML = prettyBytes(torrent.length)

          // Remaining time
          let remaining
          if (torrent.done) {
            remaining = 'Done.'
          } else {
            remaining = moment.duration(torrent.timeRemaining / 1000, 'seconds').humanize()
            remaining = remaining[0].toUpperCase() + remaining.substring(1) + ' remaining.'
          }
          $remaining.innerHTML = remaining

          // Speed rates
          $downloadSpeed.innerHTML = prettyBytes(torrent.downloadSpeed) + '/s'
          $uploadSpeed.innerHTML = prettyBytes(torrent.uploadSpeed) + '/s'
        }
        function onDone () {
          $body.className += ' is-seed'
          onProgress()
        }
      })

      // Human readable bytes util
      function prettyBytes(num) {
        const units = ['B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
        const neg = num < 0
        if (neg) num = -num
        if (num < 1) return (neg ? '-' : '') + num + ' B'
        const exponent = Math.min(Math.floor(Math.log(num) / Math.log(1000)), units.length - 1)
        const unit = units[exponent]
        num = Number((num / Math.pow(1000, exponent)).toFixed(2))
        return (neg ? '-' : '') + num + ' ' + unit
      }
    </script>
     </main>
    </body>
    </html>
  `;
  res.send(html);
});

app.listen(PORT, () => {
  console.log(`Forum listening on port ${PORT}`);
});