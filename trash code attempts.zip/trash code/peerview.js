const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const fs = require('fs');

let commentOrPostOutput = '';

app.use(bodyParser.json());

// Serve static files (CSS, JavaScript, images)
app.use(express.static('public'));

const PORT = 3001;
const POSTS_FILE = 'posts.json';

// Function to retrieve all posts from the file system
const getAllPosts = () => {
  try {
    const data = fs.readFileSync(POSTS_FILE);
    return JSON.parse(data);
  } catch (err) {
    console.error(err);
    return [];
  }
};

// Function to save all posts to the file system
const saveAllPosts = (posts) => {
  fs.writeFileSync(POSTS_FILE, JSON.stringify(posts));
};

// Route to handle adding a new post
app.post('/posts', (req, res) => {
  const newPost = {
    id: Date.now(),
    author: req.connection.remoteAddress,
    content: req.body.content
  };

  const posts = getAllPosts();
  posts.push(newPost);
  saveAllPosts(posts);

  res.send({ message: 'Post added successfully!' });
});

// Route to handle retrieving all posts
app.get('/posts', (req, res) => {
  res.send(getAllPosts());
});

// Route to display the main page
app.get('/', (req, res) => {
  const posts = getAllPosts();
  const html = `
<html>
<head>
  <meta charset="UTF-8">
  <title>PeerView</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <header>
    <h1>PeerView</h1>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Videos</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </nav>
  </header>
  
  <main>
    </form>
      <form action="/play" method="post">
      <input type="text" name="torrentId">
      <input type="submit" value="Play">
    </form>

      <h1>Download files using the WebTorrent protocol (BitTorrent over WebRTC).</h1>

      <form>
        <label for="torrentId">Download from a magnet link: </label>
        <input name="torrentId", placeholder="magnet:" value="magnet:?xt=urn:btih:08ada5a7a6183aae1e09d831df6748d566095a10&dn=Sintel&tr=udp%3A%2F%2Fexplodie.org%3A6969&tr=udp%3A%2F%2Ftracker.coppersurfer.tk%3A6969&tr=udp%3A%2F%2Ftracker.empire-js.us%3A1337&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337&tr=wss%3A%2F%2Ftracker.btorrent.xyz&tr=wss%3A%2F%2Ftracker.fastcast.nz&tr=wss%3A%2F%2Ftracker.openwebtorrent.com&ws=https%3A%2F%2Fwebtorrent.io%2Ftorrents%2F&xs=https%3A%2F%2Fwebtorrent.io%2Ftorrents%2Fsintel.torrent">
        <button type="submit">Download</button>
      </form>

      <h2>Log</h2>
      <div class="log"></div>

      <!-- Include the latest version of WebTorrent -->
      <script src="https://cdn.jsdelivr.net/npm/webtorrent@latest/webtorrent.min.js"></script>

      <script>
        const client = new WebTorrent()

        client.on('error', function (err) {
          console.error('ERROR: ' + err.message)
        })

        document.querySelector('form').addEventListener('submit', function (e) {
          e.preventDefault() // Prevent page refresh

          const torrentId = document.querySelector('form input[name=torrentId]').value
          log('Adding ' + torrentId)
          client.add(torrentId, onTorrent)
        })

        function onTorrent (torrent) {
          log('Got torrent metadata!')
          log(
            'Torrent info hash: ' + torrent.infoHash + ' ' +
            '<a href="' + torrent.magnetURI + '" target="_blank">[Magnet URI]</a> ' +
            '<a href="' + torrent.torrentFileBlobURL + '" target="_blank" download="' + torrent.name + '.torrent">[Download .torrent]</a>'
          )

          // Print out progress every 5 seconds
          const interval = setInterval(function () {
            log('Progress: ' + (torrent.progress * 100).toFixed(1) + '%')
          }, 5000)

          torrent.on('done', function () {
            log('Progress: 100%')
            clearInterval(interval)
          })

          // Render all files into to the page
          torrent.files.forEach(function (file) {
            file.appendTo('.log')
            log('(Blob URLs only work if the file is loaded from a server. "http//localhost" works. "file://" does not.)')
            file.getBlobURL(function (err, url) {
              if (err) return log(err.message)
              log('File done.')
              log('<a href="' + url + '">Download full file: ' + file.name + '</a>')
            })
          })
        }

        function log (str) {
          const p = document.createElement('p')
          p.innerHTML = str
          document.querySelector('.log').appendChild(p)
        }
      </script>
      <h3>Description</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in porta lectus. Nullam volutpat, metus vel hendrerit vestibulum, ex tellus sollicitudin enim, a commodo dui purus eget risus. Nam accumsan erat in arcu feugiat, auctor vestibulum velit blandit. In hac habitasse platea dictumst. Aliquam erat volutpat. Nullam blandit bibendum vestibulum. Nam tincidunt massa velit, a suscipit mi dictum sit amet. Sed euismod elit eu urna tempor, et commodo est volutpat. Proin eget fermentum enim, id aliquam magna. Sed auctor nulla at congue eleifend. Sed blandit mauris at risus placerat, ut dapibus risus eleifend. Sed auctor odio in congue semper.</p>
    </main>
  
    <footer>
      <p>Copyright &copy; PeerView 2023</p>
    </footer>
  </body>
</html>
  `;
  res.send(html);
});

app.listen(PORT, () => {
  console.log(`Forum listening on port ${PORT}`);
});