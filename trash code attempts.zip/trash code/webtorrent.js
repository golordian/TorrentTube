const client = new WebTorrent();

const form = document.querySelector('form');
const magnetInput = document.querySelector('input[name="magnet"]');

form.addEventListener('submit', (event) => {
  event.preventDefault();

  const torrentId = magnetInput.value;
  client.add(torrentId, function (torrent) {
    const file = torrent.files.find(function (file) {
      return file.name.endsWith('.mp4')
    });

    file.appendTo('body');
  });
});
