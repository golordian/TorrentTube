const express = require('express');
const multer = require('multer');
const path = require('path');

const app = express();
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

// Set storage engine
const storage = multer.diskStorage({
  destination: './public/uploads/',
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});

// Init upload
const upload = multer({
  storage: storage,
  limits: { fileSize: 1000000 }, // limit file size to 1 MB
  fileFilter: function (req, file, cb) {
    checkFileType(file, cb);
  }
}).single('videoFile');

// Check File Type
function checkFileType(file, cb) {
  // Allowed ext
  const filetypes = /mp4/;
  // Check ext
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  // Check mime
  const mimetype = filetypes.test(file.mimetype);

  if (mimetype && extname) {
    return cb(null, true);
  } else {
    cb('Error: Only .mp4 files are allowed!');
  }
}

// Set public folder as static folder
app.use(express.static('./public'));

// Upload route
app.post('/upload', (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      res.render('index', {
        msg: err
      });
    } else {
      if (req.file == undefined) {
        res.render('index', {
          msg: 'Error: No file selected!'
        });
      } else {
        res.render('index', {
          msg: 'File uploaded!',
          file: `uploads/${req.file.filename}`
        });
      }
    }
  });
});

// Display all files in an index page
app.get('/', (req, res) => {
  const filePaths = getFiles();
  res.render('index', { files: filePaths });
});

function getFiles() {
  // Logic to retrieve all files in the uploads folder
  // Example using fs module:
  const fs = require('fs');
  const uploadPath = path.join(__dirname, 'public', 'uploads');
  return fs.readdirSync(uploadPath);
}

// Start the server
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`Server started on port ${port}`));
